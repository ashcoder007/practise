
public class WrapperExample2{
    public static void main(String[] args) {
        Integer a=new Integer(3);
        int i=a.intValue();
        Integer j=a;
		System.out.println(a+"\n"+i+"\n"+j);
    }
}
		
		
		
		
